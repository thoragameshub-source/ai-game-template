# 🎚️ Níveis de complexidade — `ai-game-template`

> Objetivo: **agilidade e economia de tokens**. Quanto menos arquivos a IA lê e mantém, menos contexto gasto e menos retrabalho. Cada projeto usa **o menor nível que o protege de erros**. O nível é definido no **Startup building** (veja a seção 4).

## 1. Os três níveis

| | 🟢 SIMPLES | 🟡 MÉDIO | 🔴 COMPLEXO |
|---|---|---|---|
| **Exemplos** | Game jam, protótipo, mini-jogo de 1 mecânica | Jogo curto com economia, fases e lançamento em loja | Jogo online, free-to-play, conteúdo extenso, time com papéis |
| **Arquivos obrigatórios no SOURCE** | 15 | 32 | 36 (+ módulos opcionais) |
| **Congelamento do SOURCE** | opcional | por tag | gate completo (PC + PG), revisão humana |
| **Prompts de planejamento** | 1 prompt único | 1 por pasta | 1 por arquivo |
| **Limite do `contexto-master.md`** | 40 linhas | 80 linhas | 120 linhas |

> As permissões do `MODO.md` valem **nos três níveis**: em EXECUÇÃO a IA nunca edita o SOURCE.

## 2. Pontuação (5 perguntas)

Cada resposta vale 0, 1 ou 2 pontos.

| # | Pergunta | 0 ponto | 1 ponto | 2 pontos |
|---|---|---|---|---|
| 1 | **Duração e escopo** | Jam ou protótipo, até 2 semanas | Jogo curto, 1 a 3 meses | Mais de 3 meses ou conteúdo extenso |
| 2 | **Sistemas e conteúdo** | 1 mecânica central e poucas fases | Vários sistemas (economia, loot, progressão) | Muitos sistemas, meta-progressão ou conteúdo procedural grande |
| 3 | **Online** | Nenhum | Ranking ou leaderboard simples | Co-op, multiplayer ou servidor próprio |
| 4 | **Publicação e monetização** | Grátis (ex.: itch.io) | Premium em loja (Steam, mobile) | Free-to-play, compras no app ou várias plataformas |
| 5 | **Equipe** | 1 pessoa + IA | 2 a 3 pessoas | 4 ou mais, ou papéis separados (arte, áudio, design) |

| Pontos | Nível |
|---|---|
| 0 a 3 | 🟢 SIMPLES |
| 4 a 7 | 🟡 MÉDIO |
| 8 a 10 | 🔴 COMPLEXO |

**Ajustes obrigatórios**

- Pergunta 3 com resposta **2**: no mínimo **MEDIO** (multiplayer ou servidor próprio).
- Pergunta 4 com resposta **2**: no mínimo **MEDIO** (free-to-play, compras no app ou várias plataformas).
- Três ou mais respostas **2**: **COMPLEXO**.
- Na dúvida entre dois níveis, fique no **menor** e promova depois (é barato; o inverso gera retrabalho).

## 3. Arquivos por nível

✅ obrigatório · ➖ opcional (vem no pacote; mantenha só se usar) · — não existe neste nível

| Arquivo | 🟢 Simples | 🟡 Médio | 🔴 Complexo |
|---|:-:|:-:|:-:|
| `00-conceito/game-concept.md` | ✅ | ✅ | ✅ |
| `00-conceito/pilares-e-experiencia.md` | — | ✅ | ✅ |
| `00-conceito/publico-e-mercado.md` | — | ➖ | ➖ |
| `01-design/controles-e-ux.md` | — | ✅ | ✅ |
| `01-design/core-loop.md` | ✅ | ✅ | ✅ |
| `01-design/mecanicas.md` | ✅ | ✅ | ✅ |
| `01-design/narrativa-e-personagens.md` | — | ➖ | ➖ |
| `01-design/niveis-e-mundo.md` | — | ✅ | ✅ |
| `01-design/progressao-e-economia.md` | — | ✅ | ✅ |
| `02-direcao-arte-audio/art-bible.md` | — | ✅ | ✅ |
| `02-direcao-arte-audio/convencoes-de-assets.md` | — | ✅ | ✅ |
| `02-direcao-arte-audio/direcao-de-audio.md` | — | ➖ | ➖ |
| `02-direcao-arte-audio/ui-style-guide.md` | — | ➖ | ➖ |
| `03-tecnico/arquitetura-de-codigo.md` | ✅ | ✅ | ✅ |
| `03-tecnico/contrato-de-eventos.md` | ✅ | ✅ | ✅ |
| `03-tecnico/engine-e-stack.md` | ✅ | ✅ | ✅ |
| `03-tecnico/mapa-cenas-nodos.md` | ✅ | ✅ | ✅ |
| `03-tecnico/multiplayer-e-rede.md` | — | ➖ | ➖ |
| `03-tecnico/performance-e-plataformas.md` | — | ✅ | ✅ |
| `03-tecnico/pipeline-de-build.md` | — | ✅ | ✅ |
| `04-dados-de-design/README.md` | — | ✅ | ✅ |
| `04-dados-de-design/entidades.json` | ✅ | ✅ | ✅ |
| `04-dados-de-design/habilidades.csv` | — | ✅ | ✅ |
| `04-dados-de-design/inimigos.csv` | — | ✅ | ✅ |
| `05-agentes/guardrails.md` | ✅ | ✅ | ✅ |
| `05-agentes/papeis-e-fluxo.md` | — | ➖ | ➖ |
| `05-agentes/skills/corrigir-bug.md` | ✅ | ✅ | ✅ |
| `05-agentes/skills/criar-conteudo-narrativo.md` | — | ➖ | ➖ |
| `05-agentes/skills/gerar-asset-brief.md` | — | ➖ | ➖ |
| `05-agentes/skills/implementar-feature.md` | — | ✅ | ✅ |
| `05-agentes/skills/juice-e-feel.md` | ✅ | ✅ | ✅ |
| `05-agentes/skills/projetar-mecanica.md` | — | ✅ | ✅ |
| `05-agentes/skills/prototipar-greybox.md` | ✅ | ✅ | ✅ |
| `05-agentes/skills/revisar-entrega.md` | ✅ | ✅ | ✅ |
| `06-qualidade/checklist-revisao.md` | — | ✅ | ✅ |
| `06-qualidade/definicao-de-pronto.md` | ✅ | ✅ | ✅ |
| `06-qualidade/playtest-e-balanceamento.md` | — | ✅ | ✅ |
| `07-producao/escopo-mvp.md` | — | ✅ | ✅ |
| `07-producao/roadmap-e-marcos.md` | — | — | ✅ |
| `08-referencias/exemplos-de-saida/exemplo-gdd-feature.md` | — | — | ➖ |
| `08-referencias/jogos-referencia.md` | — | — | ✅ |
| `08-referencias/templates/template-asset-brief.md` | — | — | ✅ |
| `08-referencias/templates/template-gdd-feature.md` | — | — | ✅ |
| `09-decisoes/ADR-000-modelo.md` | — | ✅ | ✅ |
| `09-decisoes/ADR-001-exemplo.md` | — | — | ➖ |
| `contexto-master.md` | ✅ | ✅ | ✅ |

> Fonte: `niveis.json` (gerado pela factory). Não edite à mão.

## 4. Como o nível é definido

**Automático (recomendado): Startup building.** O template nasce em `modo: STARTUP`. Ao abrir o projeto e digitar `/startup` (Claude Code) ou "startup" (Cowork/outros agentes), o agente faz até 2 rodadas de perguntas, calcula a pontuação com `tools/startup.py pontuar`, mostra o **diagnóstico** para você aprovar, cria a estrutura do nível a partir de `niveis/<nivel>.zip`, pré-preenche o SOURCE, renomeia a pasta e entra em **PLANEJAMENTO**.

**Manual:** baixe `niveis/<nivel>.zip` do repositório do template, descompacte numa pasta com o nome do projeto (`NOMENCLATURA.md`) e preencha `projeto:` no `MODO.md`.

## 5. Prompts por nível
Os prompts do seu nível estão em `PROMPTS-PLANEJAMENTO.md` (gerado só com os arquivos que você tem).

## 6. Promoção de nível

**Quando promover**

- O jogo ganhou meta-progressão, economia ou várias fases
- Entrou multiplayer, ranking ou monetização
- Entrou mais gente (arte, áudio, design separados)
- Os playtests mostram desbalanceamento recorrente: falta `playtest-e-balanceamento` e os dados completos

**Como promover** (humano roda; baixe `niveis/complexo.zip` do template):
```
python tools/nivel.py promover --nivel MEDIO --origem complexo.zip
python tools/nivel.py promover --nivel MEDIO --origem complexo.zip --aplicar
```
1. O comando copia os arquivos que faltam e atualiza o `nivel:` do `MODO.md`.
2. Volte `modo:` para `PLANEJAMENTO` (registre o motivo no `MODO.md`).
3. Gere só os arquivos novos com os prompts do novo nível e atualize o mapa do `contexto-master.md`.
4. Rode `verificar`, congele de novo e incremente a versão do SOURCE.

## 7. Regras de economia de tokens

1. **Contexto-master curto**: respeite o limite do nível; detalhe vai nos outros arquivos.
2. **Mapa "leia quando..."**: a IA lê só o que a tarefa pede.
3. **Um arquivo por vez** em PLANEJAMENTO (no MÉDIO, uma pasta por vez).
4. **Sem duplicação**: um fato mora em um arquivo; os outros apontam para ele.
5. **Sem arquivo vazio**: módulo opcional que você não usa deve ser apagado, junto com a linha dele no mapa do `contexto-master.md`.
6. **Exemplos reais curtos** valem mais que instruções longas.
7. **Não reexplique o projeto na conversa**: melhore o SOURCE em PLANEJAMENTO e congele.

## 8. Conformidade automática

| Comando | O que faz |
|---|---|
| `python tools/nivel.py verificar` | Confere `modo:` e `nivel:`, arquivos obrigatórios, placeholders `<...>` (erro em EXECUÇÃO, aviso em PLANEJAMENTO) e tamanho do contexto-master |
| `python tools/nivel.py proteger --base origin/main` | Se a base está em EXECUÇÃO, **bloqueia** PRs que alterem `SOURCE/`, `niveis.json` ou `tools/` |

O workflow `.github/workflows/verificar-nivel.yml` roda os dois a cada push e PR. Ative **branch protection** na `main` exigindo esse check.
